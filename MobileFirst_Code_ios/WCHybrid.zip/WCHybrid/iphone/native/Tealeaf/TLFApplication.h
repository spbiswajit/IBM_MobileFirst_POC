/* Product(s):                                                    */
/* Tealeaf CX Mobile iOS SDK                                      */
/* 5725-K23                                                       */
/*                                                                */
/* Copyright IBM Corp. 2014										  */
/* All rights reserved.                                           */
/* US Government Users Restricted Rights -                        */
/* Use, duplication or disclosure restricted                      */
/* by GSA ADP Schedule Contract with IBM Corp.                    */
/*                                                                */
/* Licensed Materials-Property of IBM                             */
/*                                                                */


#import <UIKit/UIKit.h>
#import "TLFPublicDefinitions.h"

@interface TLFApplication : UIApplication  {
}

@end
