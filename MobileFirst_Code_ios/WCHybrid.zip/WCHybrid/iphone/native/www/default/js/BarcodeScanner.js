
/* JavaScript content from js/BarcodeScanner.js in folder common */
var BarcodeScanner = function() {
    // mutex - Cordova plugin doesn't cope well if called twice
    scanning: false;
};

BarcodeScanner.prototype.doScan = function() {
    if (!scanning) {
        scanning = true;
        return cordova.exec(this.publish, this.publish, "org.apache.cordova.barcodeScanner", "scan", null);
    }
};

BarcodeScanner.prototype.publish = function(result) {
    scanning = false;
    require(["dojo/topic"], function(topic){
        topic.publish("barcodescanner/scans", result);
    });
};

function dojoInit() {
    // added dojo/on and dojo/topic
    require([ "dojo", "dojo/on", "dojo/topic", "dojo/parser", "dojox/mobile", "dojox/mobile/compat", "dojox/mobile/deviceTheme", "dojox/mobile/ScrollableView", "dojox/mobile/Heading", "dojox/mobile/RoundRectList" ],
            function(dojo, on, topic) {
                dojo.ready(function() {
                    // create a new BarcodeScanner object
                    scanner = new BarcodeScanner();
                   
                    // get a reference to our RoundRectList
                    list = dijit.byId("scanList");
                   
                    // add a click handler to the image that will invoke the Cordova plugin
                    on(dojo.byId("scanButton"), "click", function() { scanner.doScan(); });
                   
                    // subscribe to the topic
                    topic.subscribe("barcodescanner/scans", function(result) {
                        if(!result.cancelled && result.text) {
                            // add a new ListItem
                            list.addChild(new dojox.mobile.ListItem({'label': result.text}));
                        } else {
                            alert("Scanning error");
                        }
                    });
                });
            });
}