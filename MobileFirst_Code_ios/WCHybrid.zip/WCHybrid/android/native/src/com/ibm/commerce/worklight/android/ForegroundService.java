package com.ibm.commerce.worklight.android;

public class ForegroundService extends com.worklight.androidgap.WLForegroundService{
	//Nothing to do here...
}