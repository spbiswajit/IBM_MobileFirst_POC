package com.ibm.commerce.worklight.android;
/*
 ******************************************************************
 * Licensed Materials - Property of IBM
 *
 * WebSphere Commerce
 *
 * (C) Copyright IBM Corp. 2013 All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 *******************************************************************
 *
 *******************************************************************
 * The sample contained herein is provided to you "AS IS".
 *
 * It is furnished by IBM as a simple example and has not been  
 * thoroughly tested
 * under all conditions.  IBM, therefore, cannot guarantee its 
 * reliability, serviceability or functionality.  
 *
 * This sample may include the names of individuals, companies, brands 
 * and products in order to illustrate concepts as completely as 
 * possible.  All of these names
 * are fictitious and any similarity to the names and addresses used by 
 * actual persons 
 * or business enterprises is entirely coincidental.
 *******************************************************************
*/

/**
 * Placeholder for the implementation of a <code>GCMIntentService</code> intent service
 * subclassed from <code>com.worklight.androidgap.push.GCMIntentService</code> to handle
 * Google Cloud Messaging (GCM) messages.
 */
public class GCMIntentService extends com.worklight.androidgap.push.GCMIntentService{
    //Nothing to do here...
    private static final String CLASS_NAME = GCMIntentService.class.getName();
}
